<?php

add_ux_builder_shortcode('woocommerce_cart', array(
  'name' => __( 'WC Cart' ),
  'hidden' => true
) );
