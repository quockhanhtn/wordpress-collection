<?php

return array(
    'normal' => array( 'title' => 'Normal'),
    'uppercase'   => array( 'title' => 'UPPERCASE'),
);
