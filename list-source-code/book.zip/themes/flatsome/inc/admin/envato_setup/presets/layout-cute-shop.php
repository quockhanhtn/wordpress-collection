<?php 
/* 
  
    $type_nav = get_theme_mod('type_nav', array('font-family'=> 'Lato','variant' => '700'));
    $type_texts = get_theme_mod('type_texts', array('font-family'=> 'Lato','variant' => '400'));
    $type_headings = get_theme_mod('type_headings',array('font-family'=> 'Lato','variant' => '700'));
    $type_alt = get_theme_mod('type_alt', array('font-family'=> 'Dancing Script')); */

return array("preset_home" => 'Cute Shop','type_headings' => array('font-family'=> 'Slabo 27px'), 'type_texts' => array('font-family'=> 'Open Sans'), 'type_nav' => array('font-family'=> 'Montserrat','variant' => '400'), "dropdown_border" => "#fff","dropdown_bg" => "#FFF","color_primary" => "#a16695","footer_bottom_align" => "center", "footer_1" => "0","footer_2" => "0", "footer_bottom_text" => "light", "footer_bottom_color" => '#fff');