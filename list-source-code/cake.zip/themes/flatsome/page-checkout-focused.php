<?php
// Depricated template file. You can now change Checkout style in Theme Options > Shop > Cart & Checkout.
wc_get_template_part('checkout/layouts/checkout', get_theme_mod('checkout_layout'));
?>
