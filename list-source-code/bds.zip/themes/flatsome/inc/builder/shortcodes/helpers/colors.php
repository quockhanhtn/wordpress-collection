<?php

return array(
    array('title' => 'Dark',    'value' => 'rgb(0,0,0)'),
    array('title' => 'White',   'value' => 'rgb(255,255,255)'),
    array('title' => 'Primary', 'value' => flatsome_option('color_primary')),
    array('title' => 'Secondary', 'value' => flatsome_option('color_secondary')),
    array('title' => 'Success', 'value' => flatsome_option('color_success')),
);
